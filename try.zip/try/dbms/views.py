from django.shortcuts import render
from django.http import HttpResponse, Http404
from .models import Data


def index(request):
    return render(request, 'dbms/index.html')

def signup(request):
    return render(request, 'dbms/signup.html')

def login(request):
    return render(request, 'dbms/login.html')

def submit(request):
    #if request.method = 'POST':
    data = request.POST.dict()
    farmer = Data(
        name = data.get('name'),
        mobile_number = data.get('mobile_number'),
        residence = data.get('residence'),
        aadhar = data.get('aadhar'),
        user_name = data.get('user_name'),
        password = data.get('password')
        )
    farmer.save()
    #return HttpResponse("%s Thanks for Registering with us !" % Name)
    return render(request, 'dbms/signupSuccess.html', {'data': data,})

def authenticate_user(request):
    data = request.POST.dict()
    user_name = data.get("user_name")
    password = data.get("password")
    try:
        farmer = Data.objects.get(pk = user_name)
    except Data.DoesNotExist:
        raise Http404("Incorrect User Name")
    if farmer.password == password:
        return render(request, 'dbms/dashboard.html', {'farmer': farmer})
    else: 
        return render(request, 'dbms/loginFail.html')


# Create your views here.
